from django.apps import AppConfig


class FormappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'formapp'
